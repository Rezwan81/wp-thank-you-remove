<?php
/**
 * @package admin thank you remove
 */
/*

Plugin Name: admin thank you remove
Plugin URI: https://devles.com/
Description: This is wordpress thank you text removebal 
Author: Rezwan Shiblu
Author URI: https://devles.com/
Version: 1.0
License: GPLv2 or later
Text Domain: admin thank you remove
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Rezwan,Sylhet, Bangladesh.

Copyright 2020.
*/

//admin footer modification

 function remove_footer_admin () {
    echo '<span id="footer-thankyou"> <a href="#" target="_blank"></a></span>';
}
 
add_filter('admin_footer_text', 'remove_footer_admin');






